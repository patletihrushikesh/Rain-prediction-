Project Title: Rainfall Prediction in Australia
Group ID: 27

--- Package Requirements ---
- Python 3.x
- pandas
- numpy
- scikit-learn
- matplotlib
- seaborn

--- Run Instructions ---
1. Ensure all required libraries are installed using: pip install pandas numpy scikit-learn matplotlib seaborn
2. Place the 'weatherAUS.csv' dataset in the same folder as the notebook.
3. Open 'Rainfall_Prediction.ipynb' in Jupyter Notebook or Google Colab.
4. Run all cells sequentially to view data cleaning, model training, and final predictions.